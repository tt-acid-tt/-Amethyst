package ru.white.module.impl.render;

import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.white.manager.event_impl.EventRender3D;
import ru.white.manager.events.orbit.EventHandler;
import ru.white.module.api.Category;
import ru.white.module.api.Module;
import ru.white.module.api.ModuleInfo;
import ru.white.module.api.settings.impl.BooleanSetting;
import ru.white.module.api.settings.impl.ModeSetting;
import ru.white.module.api.settings.impl.SliderSetting;
import ru.white.utils.other.Instance;
import ru.white.utils.render.shader.WetWorldPipeline;

import java.awt.Color;

@ModuleInfo(
        name = "Wet World",
        desc = "Makes blocks appear wet with real-time reflections and ripples",
        category = Category.RENDER
)
public class WetWorld extends Module {

    public ModeSetting quality = new ModeSetting(this, "Quality", "High", "Low", "Medium", "Ultra");
    public SliderSetting reflectionStrength = new SliderSetting(this, "Reflection Strength", 0.75f, 0.1f, 1.5f, 0.05f);
    public SliderSetting darkening = new SliderSetting(this, "Wet Darkening", 0.30f, 0.0f, 0.8f, 0.05f);
    public BooleanSetting ripples = new BooleanSetting(this, "Ripples", true);
    public SliderSetting rippleSpeed = new SliderSetting(this, "Ripple Speed", 1.0f, 0.1f, 3.0f, 0.1f)
            .setVisible(() -> ripples.getValue());
    public BooleanSetting rainOnly = new BooleanSetting(this, "Rain Only", false);

    public int getQualityIndex() {
        if (quality.is("Low")) return 0;
        if (quality.is("Medium")) return 1;
        if (quality.is("High")) return 2;
        if (quality.is("Ultra")) return 3;
        return 2;
    }

    @EventHandler
    public void onRender3D(EventRender3D event) {
        if (!isEnabled()) return;
        if (mc.world == null || mc.player == null || mc.gameRenderer == null || mc.options == null) return;

        float tickDelta = event.getTickDelta();

        // World#getRainGradient существует в 1.21.11 (проверено по yarn).
        float rainGradient = mc.world.getRainGradient(tickDelta);

        if (rainOnly.getValue() && rainGradient <= 0.01f) {
            return;
        }

        Camera camera = mc.gameRenderer.getCamera();
        if (camera == null) return;

        Vec3d camPos = camera.getCameraPos();

        // GameRenderer#getFov приватный в 1.21.11 — берём FOV из настроек,
        // как это делают ScanWorld и Projection в этом же проекте.
        float fov = mc.options.getFov().getValue().floatValue();

        Matrix4f proj = mc.gameRenderer.getBasicProjectionMatrix(fov);
        if (proj == null) return;

        Matrix4f invProj = new Matrix4f(proj).invert();
        Matrix4f viewRot = new Matrix4f().rotation(camera.getRotation());

        float effectiveStrength = reflectionStrength.getValue();
        if (rainOnly.getValue()) {
            effectiveStrength *= Math.clamp(rainGradient, 0.0f, 1.0f);
        }

        float time = (float) ((System.currentTimeMillis() % 120_000L) / 1000.0);

        // Состыковка тумана: WorldTweaks (если включён) -> иначе дальность прорисовки.
        // WorldTweaks.fog — это fogEnd в блоках, fogStart берём как в BackGroundRendererMixin (start=2)
        // с мягким переходом: end*0.75 как в оригинале Redux.
        float fogStart;
        float fogEnd;
        float fogActive = 0f;
        Color fogColor = new Color(0, 0, 0, 0);
        float fogBrightness = 1.0f;

        WorldTweaks tweaks = null;
        try {
            tweaks = Instance.get(WorldTweaks.class);
        } catch (Throwable ignored) {
            tweaks = null;
        }

        if (tweaks != null && tweaks.isEnabled() && tweaks.fogs.getValue()) {
            fogEnd = tweaks.fog.getValue();
            fogStart = fogEnd * 0.75f;
            int col = tweaks.getColor();
            int a = (col >>> 24) & 0xFF;
            int r = (col >> 16) & 0xFF;
            int g = (col >> 8) & 0xFF;
            int b = col & 0xFF;
            // brightness в Nightix нет — оставляем 1.0, альфу берём из цвета темы,
            // чтобы шейдер реально подмешивал туман (uFogColor.a > 0.001).
            fogColor = new Color(r, g, b, Math.clamp(a, 0, 255));
            fogActive = 1.0f;
        } else {
            int viewDist = mc.options.getClampedViewDistance();
            fogEnd = viewDist * 16.0f;
            fogStart = fogEnd * 0.75f;
        }

        WetWorldPipeline.render(
                proj,
                invProj,
                viewRot,
                camPos,
                fov,
                effectiveStrength,
                darkening.getValue(),
                time,
                getQualityIndex(),
                ripples.getValue(),
                rippleSpeed.getValue(),
                rainGradient,
                fogStart,
                fogEnd,
                fogActive,
                fogColor,
                fogBrightness
        );
    }
}
