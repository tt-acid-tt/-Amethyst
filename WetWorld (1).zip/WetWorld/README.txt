УСТАНОВКА
1. Скопируй WetWorld.java в:
   src\client\java\ru\white\module\impl\render\

2. Скопируй WetWorldPipeline.java в:
   src\client\java\ru\white\utils\render\shader\

3. Открой src\client\java\ru\white\utils\render\shader\ShaderData.java,
   найди в static-блоке строку:
     SOURCES.put("core/molten_metal|fsh", ...);
   и ПОСЛЕ неё вставь целиком содержимое ShaderData_vsh.txt
   и ShaderData_fsh.txt (каждый — одной строкой, как там).

4. Открой src\client\java\ru\white\module\api\ModuleManager.java,
   в список addSorted(...) добавь строку:
     new WetWorld(),
   например после new ScanWorld(), — импорт не нужен
   (модуль в том же пакете ru.white.module.impl.render.*).

ЕСЛИ НЕ МОДУЛЯ НЕТУ:
- Нет модуля в GUI — проверь шаг 4 (регистрация).
